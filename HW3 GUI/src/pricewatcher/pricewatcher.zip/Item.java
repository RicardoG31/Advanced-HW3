package pricewatcher;

public class Item {
	public String name = ("Sony SRS-XB41 Portable Wireless Bluetooth Speaker, Black (SRSXB41/B)");
	public String url = ("https://www.amazon.com/Sony-SRS-XB41-Portable-Bluetooth-SRSXB41/dp/B079V81NSG/ref=sr_1_acs_osp_osp18-1d0bb696_cov_4_2?s=electronics&ie=UTF8&qid=1549252925&sr=1-4-acs&keywords=bluetooth+speaker&tag=thewire06oa-20&ascsubtag=1d0bb696-435c-4008-a72b-1f50c7c75bc2&linkCode=oas&cv_ct_id=amzn1.osp.1d0bb696-435c-4008-a72b-1f50c7c75bc2&cv_ct_pg=search&cv_ct_wn=osp-search&creativeASIN=B079V81NSG");
	public double maxPrice = 249.99;
	public double currentPrice = 198.00;
	public String dateAdded = ("11/10/2018");

	public String getName() {
		return name;
	}

	public void setName(String newName) {
		this.name = newName;
	}

	public void setPrice(double newPrice) {
		this.maxPrice = newPrice;
	}

	public double getPrice() {
		return maxPrice;
	}
	
	public void setCurrentPrice(double newCurrentPrice) {
		this.currentPrice = newCurrentPrice;
	}
	
	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setURL(String newURL) {
		this.url = newURL;
	}

	public String getURL() {
		return url;
	}

	public void setdateAdded(String newdateAdded) {
		this.dateAdded = newdateAdded;
	}

	public String getdateAdded() {
		return dateAdded;
	}

	public double changeInPrice() {
		double increase = maxPrice - currentPrice;
		increase = (increase / maxPrice) * 100;
		return increase;

	}
}